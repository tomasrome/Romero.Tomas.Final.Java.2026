package rentalmedicogatotuerto.controller;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;

public class BienvenidaController {

    @FXML
    private void onIngresar(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/rentalmedicogatotuerto/MainView.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("El Gato Tuerto - Rental Médico");
            stage.show();
        } catch (IOException e) {
            System.out.println("Error al cargar la vista principal: " + e.getMessage());
        }
    }
}
