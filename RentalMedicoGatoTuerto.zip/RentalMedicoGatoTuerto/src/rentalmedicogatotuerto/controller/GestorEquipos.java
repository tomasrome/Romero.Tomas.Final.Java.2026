package rentalmedicogatotuerto.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import rentalmedicogatotuerto.model.EquipoMedico;
import rentalmedicogatotuerto.model.enums.EstadoEquipo;
import rentalmedicogatotuerto.model.exceptions.EquipoNoDisponibleException;
import rentalmedicogatotuerto.model.exceptions.EquipoNoEncontradoException;
import rentalmedicogatotuerto.model.interfaces.IGestionable;
import rentalmedicogatotuerto.utils.EquipoComparator;
import rentalmedicogatotuerto.utils.EquipoIterator;

public class GestorEquipos implements IGestionable<EquipoMedico>, Iterable<EquipoMedico> {

    private List<EquipoMedico> lista;

    public GestorEquipos() {
        this.lista = new ArrayList<>();
    }

    @Override
    public List<EquipoMedico> obtenerTodos() {
        return lista;
    }

    @Override
    public EquipoMedico buscarPorId(int id) throws EquipoNoEncontradoException {
        for (EquipoMedico e : lista) {
            if (e.getId() == id) {
                return e;
            }
        }
        throw new EquipoNoEncontradoException(id);
    }

    @Override
    public void agregar(EquipoMedico equipo) {
        lista.add(equipo);
    }

    @Override
    public void actualizar(EquipoMedico equipo) throws EquipoNoEncontradoException {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getId() == equipo.getId()) {
                lista.set(i, equipo);
                return;
            }
        }
        throw new EquipoNoEncontradoException(equipo.getId());
    }

    @Override
    public void eliminar(int id) throws Exception {
        EquipoMedico equipo = buscarPorId(id);
        lista.remove(equipo);
    }

    public void modificarTodos(Consumer<EquipoMedico> accion) {
        for (EquipoMedico e : lista) {
            accion.accept(e);
        }
    }

    public List<EquipoMedico> filtrar(Predicate<EquipoMedico> criterio) {
        List<EquipoMedico> toReturn = new ArrayList<>();
        for (EquipoMedico e : lista) {
            if (criterio.test(e)) {
                toReturn.add(e);
            }
        }
        return toReturn;
    }

    public void alquilarEquipo(int id) throws EquipoNoEncontradoException, EquipoNoDisponibleException {
        EquipoMedico equipo = buscarPorId(id);
        if (equipo.getEstado() != EstadoEquipo.DISPONIBLE) {
            throw new EquipoNoDisponibleException(equipo.getNombre());
        }
        equipo.cambiarEstado(EstadoEquipo.ALQUILADO);
    }

    public double calcularPrecioPromedio(List<? extends EquipoMedico> lista) {
        double total = 0;
        for (EquipoMedico e : lista) {
            total += e.getPrecioPorDia();
        }
        return lista.isEmpty() ? 0 : total / lista.size();
    }

    public void ordenarPorNombre() {
        Collections.sort(lista);
    }

    public void ordenarPorPrecio() {
        lista.sort(EquipoComparator.porPrecio());
    }

    public void ordenarPorEstado() {
        lista.sort(EquipoComparator.porEstado());
    }

    @Override
    public Iterator<EquipoMedico> iterator() {
        return new EquipoIterator(lista);
    }

    public List<EquipoMedico> getLista() {
        return lista;
    }
}
