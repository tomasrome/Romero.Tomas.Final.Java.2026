package rentalmedicogatotuerto.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.beans.property.*;
import javafx.scene.layout.HBox;
import rentalmedicogatotuerto.model.EquipoMedico;
import rentalmedicogatotuerto.model.Monitor;
import rentalmedicogatotuerto.model.Respirador;
import rentalmedicogatotuerto.model.Camilla;
import rentalmedicogatotuerto.model.enums.EstadoEquipo;
import rentalmedicogatotuerto.model.enums.TipoMonitor;
import rentalmedicogatotuerto.model.enums.TipoRespirador;
import rentalmedicogatotuerto.model.enums.TipoCamilla;
import rentalmedicogatotuerto.model.exceptions.EquipoNoEncontradoException;
import rentalmedicogatotuerto.model.interfaces.IInspeccionable;
import rentalmedicogatotuerto.utils.PersistenciaManager;

public class MainController {

    @FXML
    private TableView<EquipoMedico> tablaEquipos;
    @FXML
    private TableColumn<EquipoMedico, Integer> colId;
    @FXML
    private TableColumn<EquipoMedico, String> colNombre;
    @FXML
    private TableColumn<EquipoMedico, String> colMarca;
    @FXML
    private TableColumn<EquipoMedico, Double> colPrecio;
    @FXML
    private TableColumn<EquipoMedico, String> colEstado;
    @FXML
    private TableColumn<EquipoMedico, String> colTipo;
    @FXML
    private Label lblMensaje;
    @FXML
    private Button btnTodos;
    @FXML
    private Button btnMonitores;
    @FXML
    private Button btnRespiradores;
    @FXML
    private Button btnCamillas;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnActualizar;
    @FXML
    private Button btnAgregarMonitor;
    @FXML
    private Button btnAgregarRespirador;
    @FXML
    private Button btnAgregarCamilla;

    @FXML
    private HBox panelMonitor;
    @FXML
    private HBox panelRespirador;
    @FXML
    private HBox panelCamilla;

    @FXML
    private TextField fNombre;
    @FXML
    private TextField fMarca;
    @FXML
    private TextField fPrecio;
    @FXML
    private ComboBox<EstadoEquipo> fEstado;
    @FXML
    private ComboBox<TipoMonitor> fTipoMonitor;
    @FXML
    private CheckBox fAlarma;

    @FXML
    private TextField fNombreR;
    @FXML
    private TextField fMarcaR;
    @FXML
    private TextField fPrecioR;
    @FXML
    private ComboBox<EstadoEquipo> fEstadoR;
    @FXML
    private ComboBox<TipoRespirador> fTipoRespirador;
    @FXML
    private CheckBox fPortatil;

    @FXML
    private TextField fNombreC;
    @FXML
    private TextField fMarcaC;
    @FXML
    private TextField fPrecioC;
    @FXML
    private ComboBox<EstadoEquipo> fEstadoC;
    @FXML
    private ComboBox<TipoCamilla> fTipoCamilla;
    @FXML
    private TextField fPeso;

    private GestorEquipos gestor = new GestorEquipos();
    private ObservableList<EquipoMedico> listaObservable;
    private int contadorId = 1;
    private boolean modoEdicion = false;
    private EquipoMedico equipoEnEdicion = null;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getId()).asObject());
        colNombre.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNombre()));
        colMarca.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMarca()));
        colPrecio.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getPrecioPorDia()).asObject());
        colEstado.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEstado().toString()));
        colTipo.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getClass().getSimpleName()));

        fEstado.setItems(FXCollections.observableArrayList(EstadoEquipo.values()));
        fEstadoR.setItems(FXCollections.observableArrayList(EstadoEquipo.values()));
        fEstadoC.setItems(FXCollections.observableArrayList(EstadoEquipo.values()));
        fTipoMonitor.setItems(FXCollections.observableArrayList(TipoMonitor.values()));
        fTipoRespirador.setItems(FXCollections.observableArrayList(TipoRespirador.values()));
        fTipoCamilla.setItems(FXCollections.observableArrayList(TipoCamilla.values()));

        listaObservable = FXCollections.observableArrayList(gestor.getLista());
        tablaEquipos.setItems(listaObservable);
        tablaEquipos.setFixedCellSize(40);

        seleccionarBoton(btnTodos);
        btnEliminar.setDisable(true);
        btnActualizar.setDisable(true);

        tablaEquipos.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldVal, newVal) -> {
                    boolean haySeleccion = newVal != null;
                    btnEliminar.setDisable(!haySeleccion);
                    btnActualizar.setDisable(!haySeleccion);
                }
        );

        colEstado.setCellFactory(col -> new TableCell<EquipoMedico, String>() {
            @Override
            protected void updateItem(String estado, boolean empty) {
                super.updateItem(estado, empty);
                if (empty || estado == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(estado);
                    switch (estado) {
                        case "DISPONIBLE" ->
                            setStyle("-fx-background-color: #4a7a4a; -fx-text-fill: white;");
                        case "ALQUILADO" ->
                            setStyle("-fx-background-color: #7a6200; -fx-text-fill: white;");
                        case "EN_MANTENIMIENTO" ->
                            setStyle("-fx-background-color: #7a3030; -fx-text-fill: white;");
                        default ->
                            setStyle("");
                    }
                }
            }
        });
    }

    private void seleccionarBoton(Button boton) {
        btnTodos.getStyleClass().remove("boton-activo");
        btnMonitores.getStyleClass().remove("boton-activo");
        btnRespiradores.getStyleClass().remove("boton-activo");
        btnCamillas.getStyleClass().remove("boton-activo");
        boton.getStyleClass().add("boton-activo");
    }

    @FXML
    private void onActualizar() {
        EquipoMedico seleccionado = tablaEquipos.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            lblMensaje.setStyle("-fx-text-fill: #7a3030;");
            lblMensaje.setText("Seleccioná un equipo de la tabla.");
            return;
        }

        modoEdicion = true;
        equipoEnEdicion = seleccionado;

        if (seleccionado instanceof Monitor m) {
            fNombre.setText(m.getNombre());
            fMarca.setText(m.getMarca());
            fPrecio.setText(String.valueOf(m.getPrecioPorDia()));
            fEstado.setValue(m.getEstado());
            fTipoMonitor.setValue(m.getTipoMonitor());
            fAlarma.setSelected(m.isTieneAlarma());
            btnAgregarMonitor.setText("Actualizar");
            lblMensaje.setStyle("-fx-text-fill: #987c00;");
            lblMensaje.setText("Editando Monitor: " + m.getNombre());

        } else if (seleccionado instanceof Respirador r) {
            fNombreR.setText(r.getNombre());
            fMarcaR.setText(r.getMarca());
            fPrecioR.setText(String.valueOf(r.getPrecioPorDia()));
            fEstadoR.setValue(r.getEstado());
            fTipoRespirador.setValue(r.getTipoRespirador());
            fPortatil.setSelected(r.isEsPortatil());
            btnAgregarRespirador.setText("Actualizar");
            lblMensaje.setStyle("-fx-text-fill: #987c00;");
            lblMensaje.setText("Editando Respirador: " + r.getNombre());

        } else if (seleccionado instanceof Camilla c) {
            fNombreC.setText(c.getNombre());
            fMarcaC.setText(c.getMarca());
            fPrecioC.setText(String.valueOf(c.getPrecioPorDia()));
            fEstadoC.setValue(c.getEstado());
            fTipoCamilla.setValue(c.getTipoCamilla());
            fPeso.setText(String.valueOf(c.getPesoMaximoKg()));
            btnAgregarCamilla.setText("Actualizar");
            lblMensaje.setStyle("-fx-text-fill: #987c00;");
            lblMensaje.setText("Editando Camilla: " + c.getNombre());
        }
    }

    @FXML
    private void onAgregar() throws EquipoNoEncontradoException {
        try {
            String nombre = fNombre.getText();
            String marca = fMarca.getText();
            double precio = Double.parseDouble(fPrecio.getText());
            EstadoEquipo estado = fEstado.getValue();
            TipoMonitor tipo = fTipoMonitor.getValue();

            if (nombre.isEmpty() || marca.isEmpty() || estado == null || tipo == null) {
                lblMensaje.setStyle("-fx-text-fill: #7a3030;");
                lblMensaje.setText("Completá todos los campos del Monitor.");
                return;
            }

            if (modoEdicion && equipoEnEdicion instanceof Monitor) {
                if (equipoEnEdicion instanceof IInspeccionable insp) {
                    if (!insp.validarCambioEstado(equipoEnEdicion.getEstado(), estado)) {
                        lblMensaje.setStyle("-fx-text-fill: #7a3030;");
                        lblMensaje.setText("Debe pasar por DISPONIBLE antes de cambiar a " + estado);
                        return;
                    }
                }
                equipoEnEdicion.setNombre(nombre);
                equipoEnEdicion.setMarca(marca);
                equipoEnEdicion.setPrecioPorDia(precio);
                equipoEnEdicion.setEstado(estado);
                ((Monitor) equipoEnEdicion).setTipoMonitor(tipo);
                ((Monitor) equipoEnEdicion).setTieneAlarma(fAlarma.isSelected());
                gestor.actualizar(equipoEnEdicion);
                refrescarTabla();
                salirModoEdicion();
                btnAgregarMonitor.setText("Agregar");
                lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
                lblMensaje.setText("Monitor actualizado correctamente.");
            } else {
                Monitor m = new Monitor(contadorId, nombre, marca, precio, estado, tipo, fAlarma.isSelected());
                gestor.agregar(m);
                contadorId++;
                refrescarTabla();
                limpiarCamposMonitor();
                lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
                lblMensaje.setText("Monitor agregado correctamente.");
            }
        } catch (NumberFormatException e) {
            lblMensaje.setStyle("-fx-text-fill: #7a3030;");
            lblMensaje.setText("El precio debe ser un número.");
        }
    }

    @FXML
    private void onAgregarRespirador() throws EquipoNoEncontradoException {
        try {
            String nombre = fNombreR.getText();
            String marca = fMarcaR.getText();
            double precio = Double.parseDouble(fPrecioR.getText());
            EstadoEquipo estado = fEstadoR.getValue();
            TipoRespirador tipo = fTipoRespirador.getValue();

            if (nombre.isEmpty() || marca.isEmpty() || estado == null || tipo == null) {
                lblMensaje.setStyle("-fx-text-fill: #7a3030;");
                lblMensaje.setText("Completá todos los campos del Respirador.");
                return;
            }

            if (modoEdicion && equipoEnEdicion instanceof Respirador) {
                if (equipoEnEdicion instanceof IInspeccionable insp) {
                    if (!insp.validarCambioEstado(equipoEnEdicion.getEstado(), estado)) {
                        lblMensaje.setStyle("-fx-text-fill: #7a3030;");
                        lblMensaje.setText("Debe pasar por DISPONIBLE antes de cambiar a " + estado);
                        return;
                    }
                }
                equipoEnEdicion.setNombre(nombre);
                equipoEnEdicion.setMarca(marca);
                equipoEnEdicion.setPrecioPorDia(precio);
                equipoEnEdicion.setEstado(estado);
                ((Respirador) equipoEnEdicion).setTipoRespirador(tipo);
                ((Respirador) equipoEnEdicion).setEsPortatil(fPortatil.isSelected());
                gestor.actualizar(equipoEnEdicion);
                refrescarTabla();
                salirModoEdicion();
                btnAgregarRespirador.setText("Agregar");
                lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
                lblMensaje.setText("Respirador actualizado correctamente.");
            } else {
                Respirador r = new Respirador(contadorId, nombre, marca, precio, estado, tipo, fPortatil.isSelected());
                gestor.agregar(r);
                contadorId++;
                refrescarTabla();
                limpiarCamposRespirador();
                lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
                lblMensaje.setText("Respirador agregado correctamente.");
            }
        } catch (NumberFormatException e) {
            lblMensaje.setStyle("-fx-text-fill: #7a3030;");
            lblMensaje.setText("El precio debe ser un número.");
        }
    }

    @FXML
    private void onAgregarCamilla() throws EquipoNoEncontradoException {
        try {
            String nombre = fNombreC.getText();
            String marca = fMarcaC.getText();
            double precio = Double.parseDouble(fPrecioC.getText());
            EstadoEquipo estado = fEstadoC.getValue();
            TipoCamilla tipo = fTipoCamilla.getValue();
            double peso = 150.0;
            try {
                peso = Double.parseDouble(fPeso.getText());
            } catch (NumberFormatException ex) {
            }

            if (nombre.isEmpty() || marca.isEmpty() || estado == null || tipo == null) {
                lblMensaje.setStyle("-fx-text-fill: #7a3030;");
                lblMensaje.setText("Completá todos los campos de la Camilla.");
                return;
            }

            if (modoEdicion && equipoEnEdicion instanceof Camilla) {
                equipoEnEdicion.setNombre(nombre);
                equipoEnEdicion.setMarca(marca);
                equipoEnEdicion.setPrecioPorDia(precio);
                equipoEnEdicion.setEstado(estado);
                ((Camilla) equipoEnEdicion).setTipoCamilla(tipo);
                ((Camilla) equipoEnEdicion).setPesoMaximoKg(peso);
                gestor.actualizar(equipoEnEdicion);
                refrescarTabla();
                salirModoEdicion();
                btnAgregarCamilla.setText("Agregar");
                lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
                lblMensaje.setText("Camilla actualizada correctamente.");
            } else {
                Camilla c = new Camilla(contadorId, nombre, marca, precio, estado, tipo, peso);
                gestor.agregar(c);
                contadorId++;
                refrescarTabla();
                limpiarCamposCamilla();
                lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
                lblMensaje.setText("Camilla agregada correctamente.");
            }
        } catch (NumberFormatException e) {
            lblMensaje.setStyle("-fx-text-fill: #7a3030;");
            lblMensaje.setText("El precio debe ser un número.");
        }
    }

    @FXML
    private void onEliminar() {
        EquipoMedico seleccionado = tablaEquipos.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            lblMensaje.setStyle("-fx-text-fill: #7a3030;");
            lblMensaje.setText("Seleccioná un equipo de la tabla.");
            return;
        }
        try {
            gestor.eliminar(seleccionado.getId());
            refrescarTabla();
            lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
            lblMensaje.setText("Equipo eliminado correctamente.");
        } catch (Exception e) {
            lblMensaje.setStyle("-fx-text-fill: #7a3030;");
            lblMensaje.setText("Error al eliminar: " + e.getMessage());
        }
    }

    @FXML
    private void onMostrarTodos() {
        seleccionarBoton(btnTodos);
        refrescarTabla();
        lblMensaje.setText("");
    }

    @FXML
    private void onFiltrarMonitor() {
        seleccionarBoton(btnMonitores);
        listaObservable.setAll(gestor.filtrar(e -> e instanceof Monitor));
    }

    @FXML
    private void onFiltrarRespirador() {
        seleccionarBoton(btnRespiradores);
        listaObservable.setAll(gestor.filtrar(e -> e instanceof Respirador));
    }

    @FXML
    private void onFiltrarCamilla() {
        seleccionarBoton(btnCamillas);
        listaObservable.setAll(gestor.filtrar(e -> e instanceof Camilla));
    }

    @FXML
    private void onOrdenarNombre() {
        gestor.ordenarPorNombre();
        refrescarTabla();
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Lista ordenada por nombre.");
    }

    @FXML
    private void onOrdenarPrecio() {
        gestor.ordenarPorPrecio();
        refrescarTabla();
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Lista ordenada por precio.");
    }

    @FXML
    private void onAumentar() {
        gestor.modificarTodos(e -> e.setPrecioPorDia(e.getPrecioPorDia() * 1.10));
        refrescarTabla();
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Precios aumentados un 10%.");
    }

    @FXML
    private void onGuardarDat() {
        PersistenciaManager.serializarLista(gestor.getLista(), "equipos.dat");
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Lista guardada en equipos.dat");
    }

    @FXML
    private void onCargarDat() {
        java.util.List<EquipoMedico> cargada = PersistenciaManager.deserializarLista("equipos.dat");
        if (cargada != null) {
            gestor.getLista().clear();
            gestor.getLista().addAll(cargada);
            refrescarTabla();
            lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
            lblMensaje.setText("Lista cargada desde equipos.dat");
        }
    }

    @FXML
    private void onGuardarCSV() {
        PersistenciaManager.guardarCSV(gestor.getLista(), "equipos.csv");
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Lista guardada en equipos.csv");
    }

    @FXML
    private void onGuardarJSON() {
        PersistenciaManager.guardarJSON(gestor.getLista(), "equipos.json");
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Lista guardada en equipos.json");
    }

    @FXML
    private void onExportarTXT() {
        PersistenciaManager.exportarTXT(gestor.getLista(), "equipos.txt");
        lblMensaje.setStyle("-fx-text-fill: #4a7a4a;");
        lblMensaje.setText("Lista exportada en equipos.txt");
    }

    private void refrescarTabla() {
        listaObservable.setAll(gestor.getLista());
        fEstado.setItems(FXCollections.observableArrayList(EstadoEquipo.values()));
        fEstadoR.setItems(FXCollections.observableArrayList(EstadoEquipo.values()));
        fEstadoC.setItems(FXCollections.observableArrayList(EstadoEquipo.values()));
        fTipoMonitor.setItems(FXCollections.observableArrayList(TipoMonitor.values()));
        fTipoRespirador.setItems(FXCollections.observableArrayList(TipoRespirador.values()));
        fTipoCamilla.setItems(FXCollections.observableArrayList(TipoCamilla.values()));
    }

    private void salirModoEdicion() {
        modoEdicion = false;
        equipoEnEdicion = null;
        limpiarCamposMonitor();
        limpiarCamposRespirador();
        limpiarCamposCamilla();
    }

    private void limpiarCamposMonitor() {
        fNombre.clear();
        fMarca.clear();
        fPrecio.clear();
        fEstado.getSelectionModel().clearSelection();
        fTipoMonitor.getSelectionModel().clearSelection();
        fAlarma.setSelected(false);
    }

    private void limpiarCamposRespirador() {
        fNombreR.clear();
        fMarcaR.clear();
        fPrecioR.clear();
        fEstadoR.getSelectionModel().clearSelection();
        fTipoRespirador.getSelectionModel().clearSelection();
        fPortatil.setSelected(false);
    }

    private void limpiarCamposCamilla() {
        fNombreC.clear();
        fMarcaC.clear();
        fPrecioC.clear();
        fEstadoC.getSelectionModel().clearSelection();
        fTipoCamilla.getSelectionModel().clearSelection();
        fPeso.clear();
    }
}
