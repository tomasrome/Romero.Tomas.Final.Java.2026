package rentalmedicogatotuerto.model;

import rentalmedicogatotuerto.model.EquipoMedico;
import rentalmedicogatotuerto.model.enums.EstadoEquipo;
import rentalmedicogatotuerto.model.enums.TipoCamilla;

public class Camilla extends EquipoMedico {

    private TipoCamilla tipoCamilla;
    private double pesoMaximoKg;

    
    public Camilla(int id, String nombre, String marca, double precioPorDia, EstadoEquipo estado, TipoCamilla tipoCamilla, double pesoMaximoKg) {
        super(id, nombre, marca, precioPorDia, estado);
        this.tipoCamilla = tipoCamilla;
        this.pesoMaximoKg = pesoMaximoKg;
    }


    public Camilla(int id, String nombre, String marca, double precioPorDia, TipoCamilla tipoCamilla, double pesoMaximoKg) {
        super(id, nombre, marca, precioPorDia, EstadoEquipo.DISPONIBLE);
        this.tipoCamilla = tipoCamilla;
        this.pesoMaximoKg = pesoMaximoKg;
    }


    public Camilla(int id, String nombre, TipoCamilla tipoCamilla) {
        super(id, nombre, "Sin marca", 0.0, EstadoEquipo.DISPONIBLE);
        this.tipoCamilla = tipoCamilla;
        this.pesoMaximoKg = 150.0;
    }

    public TipoCamilla getTipoCamilla() {
        return tipoCamilla;
    }

    public double getPesoMaximoKg() {
        return pesoMaximoKg;
    }

    public void setTipoCamilla(TipoCamilla tipoCamilla) {
        this.tipoCamilla = tipoCamilla;
    }

    public void setPesoMaximoKg(double pesoMaximoKg) {
        this.pesoMaximoKg = pesoMaximoKg;
    }

}
