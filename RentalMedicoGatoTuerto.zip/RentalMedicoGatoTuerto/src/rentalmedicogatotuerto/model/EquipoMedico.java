package rentalmedicogatotuerto.model;

import java.io.Serializable;
import rentalmedicogatotuerto.model.enums.EstadoEquipo;

public abstract class EquipoMedico implements Comparable<EquipoMedico>, Serializable {

    private int id;
    private String nombre;
    private String marca;
    private double precioPorDia;
    private EstadoEquipo estado;

    public EquipoMedico(int id, String nombre, String marca, double precioPorDia, EstadoEquipo estado) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.precioPorDia = precioPorDia;
        this.estado = estado;
    }

    // Constructor con un parámetro menos (sin estado, por defecto DISPONIBLE)
    public EquipoMedico(int id, String nombre, String marca, double precioPorDia) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.precioPorDia = precioPorDia;
        this.estado = EstadoEquipo.DISPONIBLE;
    }

    public EquipoMedico(int id, String nombre, String marca) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.precioPorDia = 0;
        this.estado = EstadoEquipo.DISPONIBLE;
    }

    // Método concreto compartido por todos
    public double calcularCostoAlquiler(int dias) {
        return precioPorDia * dias;
    }

    // Método concreto compartido por todos
    public void cambiarEstado(EstadoEquipo nuevoEstado) {
        this.estado = nuevoEstado;
    }

    // Ordenamiento natural por nombre
    @Override
    public int compareTo(EquipoMedico otro) {
        return this.nombre.compareTo(otro.nombre);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPrecioPorDia() {
        return precioPorDia;
    }

    public void setPrecioPorDia(double precioPorDia) {
        this.precioPorDia = precioPorDia;
    }

    public EstadoEquipo getEstado() {
        return estado;
    }

    public void setEstado(EstadoEquipo estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "EquipoMedico{" + "id=" + id + ", nombre=" + nombre + ", marca=" + marca + ", precioPorDia=" + precioPorDia + ", estado=" + estado + '}';
    }

}
