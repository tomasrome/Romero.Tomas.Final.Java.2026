package rentalmedicogatotuerto.model;

import rentalmedicogatotuerto.model.EquipoMedico;
import rentalmedicogatotuerto.model.enums.EstadoEquipo;
import rentalmedicogatotuerto.model.enums.TipoMonitor;
import rentalmedicogatotuerto.model.interfaces.IInspeccionable;

public class Monitor extends EquipoMedico implements IInspeccionable {

    private TipoMonitor tipoMonitor;
    private boolean tieneAlarma;

    public Monitor(int id, String nombre, String marca, double precioPorDia, EstadoEquipo estado, TipoMonitor tipoMonitor, boolean tieneAlarma) {
        super(id, nombre, marca, precioPorDia, estado);
        this.tipoMonitor = tipoMonitor;
        this.tieneAlarma = tieneAlarma;
    }

    public Monitor(int id, String nombre, String marca, double precioPorDia, TipoMonitor tipoMonitor, boolean tieneAlarma) {
        super(id, nombre, marca, precioPorDia, EstadoEquipo.DISPONIBLE);
        this.tipoMonitor = tipoMonitor;
        this.tieneAlarma = tieneAlarma;
    }

    public Monitor(int id, String nombre, TipoMonitor tipoMonitor) {
        super(id, nombre, "Sin marca", 0.0, EstadoEquipo.DISPONIBLE);
        this.tipoMonitor = tipoMonitor;
        this.tieneAlarma = false;
    }

    @Override
    public boolean validarCambioEstado(EstadoEquipo estadoActual, EstadoEquipo estadoNuevo) {
        if (estadoActual == EstadoEquipo.EN_MANTENIMIENTO && estadoNuevo == EstadoEquipo.ALQUILADO) {
            return false;
        }
        return true;
    }

    public TipoMonitor getTipoMonitor() {
        return tipoMonitor;
    }

    public boolean isTieneAlarma() {
        return tieneAlarma;
    }

    public void setTipoMonitor(TipoMonitor tipoMonitor) {
        this.tipoMonitor = tipoMonitor;
    }

    public void setTieneAlarma(boolean tieneAlarma) {
        this.tieneAlarma = tieneAlarma;
    }

}
