package rentalmedicogatotuerto.model;

import rentalmedicogatotuerto.model.EquipoMedico;
import rentalmedicogatotuerto.model.enums.EstadoEquipo;
import rentalmedicogatotuerto.model.enums.TipoRespirador;
import rentalmedicogatotuerto.model.interfaces.IInspeccionable;

public class Respirador extends EquipoMedico implements IInspeccionable {

    private TipoRespirador tipoRespirador;
    private boolean esPortatil;

    public Respirador(int id, String nombre, String marca, double precioPorDia, EstadoEquipo estado, TipoRespirador tipoRespirador, boolean esPortatil) {
        super(id, nombre, marca, precioPorDia, estado);
        this.tipoRespirador = tipoRespirador;
        this.esPortatil = esPortatil;
    }

    public Respirador(int id, String nombre, String marca, double precioPorDia, TipoRespirador tipoRespirador, boolean esPortatil) {
        super(id, nombre, marca, precioPorDia, EstadoEquipo.DISPONIBLE);
        this.tipoRespirador = tipoRespirador;
        this.esPortatil = esPortatil;
    }

    public Respirador(int id, String nombre, TipoRespirador tipoRespirador) {
        super(id, nombre, "Sin marca", 0.0, EstadoEquipo.DISPONIBLE);
        this.tipoRespirador = tipoRespirador;
        this.esPortatil = false;
    }

    @Override
    public boolean validarCambioEstado(EstadoEquipo estadoActual, EstadoEquipo estadoNuevo) {
        if (estadoActual == EstadoEquipo.EN_MANTENIMIENTO && estadoNuevo == EstadoEquipo.ALQUILADO) {
            return false;
        }
        return true;
    }

    public TipoRespirador getTipoRespirador() {
        return tipoRespirador;
    }

    public boolean isEsPortatil() {
        return esPortatil;
    }

    public void setTipoRespirador(TipoRespirador tipoRespirador) {
        this.tipoRespirador = tipoRespirador;
    }

    public void setEsPortatil(boolean esPortatil) {
        this.esPortatil = esPortatil;
    }

}
