package rentalmedicogatotuerto.model.enums;

public enum EstadoEquipo {
    DISPONIBLE,
    ALQUILADO,
    EN_MANTENIMIENTO
}
