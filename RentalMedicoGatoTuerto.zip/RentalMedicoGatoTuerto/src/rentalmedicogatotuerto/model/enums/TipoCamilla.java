package rentalmedicogatotuerto.model.enums;

public enum TipoCamilla {
    AMBULANCIA,
    CIRUGIA,
    TERAPIA,
    HOSPITALARIA
}
