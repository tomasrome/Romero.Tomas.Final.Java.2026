
package rentalmedicogatotuerto.model.enums;


public enum TipoMonitor {
    MULTIPARAMETRICO,
    FETAL,
    PRESION_ARTERIAL,
    SIGNOS_VITALES,
}
