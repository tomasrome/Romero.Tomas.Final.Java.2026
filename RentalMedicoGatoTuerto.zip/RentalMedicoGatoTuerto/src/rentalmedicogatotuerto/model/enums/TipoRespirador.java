package rentalmedicogatotuerto.model.enums;

public enum TipoRespirador {
    INVASIVO,
    NO_INVASIVO,
    ANESTESIA
}
