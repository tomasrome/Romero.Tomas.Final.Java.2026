package rentalmedicogatotuerto.model.exceptions;

public class EquipoNoDisponibleException extends Exception {

    public EquipoNoDisponibleException(String nombreEquipo) {
        super("El equipo '" + nombreEquipo + "' no está disponible para alquilar.");
    }
}
