package rentalmedicogatotuerto.model.exceptions;

public class EquipoNoEncontradoException extends Exception {

    public EquipoNoEncontradoException(int id) {
        super("No se encontró ningún equipo con el ID: " + id);
    }
}
