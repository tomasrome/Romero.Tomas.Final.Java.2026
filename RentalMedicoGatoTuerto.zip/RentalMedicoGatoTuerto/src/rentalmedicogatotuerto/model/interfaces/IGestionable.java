package rentalmedicogatotuerto.model.interfaces;

import java.util.List;

public interface IGestionable<T> {

    List<T> obtenerTodos();

    void agregar(T elemento);

    T buscarPorId(int id) throws Exception;

    void actualizar(T elemento) throws Exception;

    void eliminar(int id) throws Exception;
}
