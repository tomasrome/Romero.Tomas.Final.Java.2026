package rentalmedicogatotuerto.model.interfaces;

import rentalmedicogatotuerto.model.enums.EstadoEquipo;

public interface IInspeccionable {

    boolean validarCambioEstado(EstadoEquipo estadoActual, EstadoEquipo estadoNuevo);
}
