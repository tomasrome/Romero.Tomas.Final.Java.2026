
package rentalmedicogatotuerto.utils;

import java.util.Comparator;
import rentalmedicogatotuerto.model.EquipoMedico;


public class EquipoComparator {
    
    public static Comparator<EquipoMedico> porPrecio() {
        return Comparator.comparing(e -> e.getPrecioPorDia());
    }

    public static Comparator<EquipoMedico> porEstado() {
        return Comparator.comparing(e -> e.getEstado().toString());
    }
}
