
package rentalmedicogatotuerto.utils;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import rentalmedicogatotuerto.model.EquipoMedico;


public class EquipoIterator implements Iterator<EquipoMedico>{
    
    private List<EquipoMedico> lista;
    private int posicionActual;

    public EquipoIterator(List<EquipoMedico> lista) {
        this.lista = lista;
        this.posicionActual = 0;
    }

    @Override
    public boolean hasNext() {
        return posicionActual < lista.size();
    }

    
    @Override
    public EquipoMedico next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No hay más equipos en la lista.");
        }
        return lista.get(posicionActual++);
    }

    
    
}
