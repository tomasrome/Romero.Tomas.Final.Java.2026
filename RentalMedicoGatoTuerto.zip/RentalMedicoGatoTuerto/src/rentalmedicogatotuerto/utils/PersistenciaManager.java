
package rentalmedicogatotuerto.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Type;
import java.util.List;
import rentalmedicogatotuerto.model.EquipoMedico;


public class PersistenciaManager {
    

    public static void serializarLista(List<EquipoMedico> lista, String archivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            System.out.println("Error al serializar: " + e.getMessage());
        }
    }

    public static List<EquipoMedico> deserializarLista(String archivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return (List<EquipoMedico>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al deserializar: " + e.getMessage());
            return null;
        }
    }


    public static void guardarCSV(List<EquipoMedico> lista, String archivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            bw.write("ID,Nombre,Marca,PrecioPorDia,Estado");
            bw.newLine();
            for (EquipoMedico e : lista) {
                bw.write(e.getId() + "," + e.getNombre() + "," + e.getMarca() + "," + e.getPrecioPorDia() + "," + e.getEstado());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error al guardar CSV: " + e.getMessage());
        }
    }

    public static void cargarCSV(String archivo, List<EquipoMedico> lista) {
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                System.out.println("Leído: " + datos[1] + " - " + datos[2]);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar CSV: " + e.getMessage());
        }
    }


    public static void guardarJSON(List<EquipoMedico> lista, String archivo) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (FileWriter fw = new FileWriter(archivo)) {
            gson.toJson(lista, fw);
        } catch (IOException e) {
            System.out.println("Error al guardar JSON: " + e.getMessage());
        }
    }

    public static List<EquipoMedico> cargarJSON(String archivo) {
        Gson gson = new Gson();
        try (FileReader fr = new FileReader(archivo)) {
            Type tipo = new TypeToken<List<EquipoMedico>>(){}.getType();
            return gson.fromJson(fr, tipo);
        } catch (IOException e) {
            System.out.println("Error al cargar JSON: " + e.getMessage());
            return null;
        }
    }
    

public static void exportarTXT(List<EquipoMedico> lista, String archivo) {
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
        bw.write("========================================");
        bw.newLine();
        bw.write("   EL GATO TUERTO - Listado de Equipos  ");
        bw.newLine();
        bw.write("========================================");
        bw.newLine();
        bw.newLine();
        for (EquipoMedico e : lista) {
            bw.write("ID: " + e.getId());
            bw.newLine();
            bw.write("Nombre: " + e.getNombre());
            bw.newLine();
            bw.write("Marca: " + e.getMarca());
            bw.newLine();
            bw.write("Precio/día: $" + e.getPrecioPorDia());
            bw.newLine();
            bw.write("Estado: " + e.getEstado());
            bw.newLine();
            bw.newLine();
            bw.write("----------------------------------------");
            bw.newLine();
        }
        System.out.println("TXT exportado correctamente en " + archivo);
    } catch (IOException e) {
        System.out.println("Error al exportar TXT: " + e.getMessage());
    }
}
}
